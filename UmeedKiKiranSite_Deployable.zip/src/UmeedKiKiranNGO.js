import React, { useEffect, useState } from "react";

export default function UmeedKiKiranNGO() {
  const [stars, setStars] = useState([]);

  useEffect(() => {
    const generatedStars = [];
    for (let i = 0; i < 100; i++) {
      generatedStars.push({
        top: Math.random() * 100 + "%",
        left: Math.random() * 100 + "%",
        size: Math.random() * 3 + 2 + "px",
        duration: Math.random() * 20 + 10 + "s",
        delay: Math.random() * 10 + "s"
      });
    }
    setStars(generatedStars);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-purple-900 text-white font-sans relative overflow-hidden">
      {/* Star Background */}
      <div className="absolute top-0 left-0 w-full h-full z-0 pointer-events-none">
        {stars.map((star, index) => (
          <div
            key={index}
            style={{
              position: "absolute",
              width: star.size,
              height: star.size,
              borderRadius: "50%",
              top: star.top,
              left: star.left,
              background: "silver",
              animation: `moveStar ${star.duration} linear infinite, blinkStar 2s ease-in-out infinite`,
              animationDelay: `${star.delay}, ${Math.random() * 2}s`
            }}
          />
        ))}
        <style>{`
          @keyframes moveStar {
            0% {
              transform: translate(0, 0);
              opacity: 0.3;
            }
            50% {
              transform: translate(50px, 50px);
              opacity: 1;
            }
            100% {
              transform: translate(0, 0);
              opacity: 0.3;
            }
          }

          @keyframes blinkStar {
            0%, 100% {
              background: silver;
              box-shadow: 0 0 5px silver;
            }
            50% {
              background: gold;
              box-shadow: 0 0 12px gold;
            }
          }
        `}</style>
      </div>

      <div className="relative z-10">
        <header className="text-center py-10">
          <h1 className="text-5xl font-bold">⭐ Umeed Ki Kiran ⭐</h1>
          <p className="text-xl mt-4">Empowering Women, Guiding Like Saturn Among the Stars</p>
        </header>

        <main className="px-6 md:px-20 lg:px-40">
          <section className="bg-purple-800 bg-opacity-50 p-6 rounded-2xl shadow-lg mb-10">
            <h2 className="text-3xl font-semibold mb-4">About Us</h2>
            <p className="text-lg mb-4">
              Umeed Ki Kiran is a movement dedicated to the empowerment of women,
              inspired by the guiding light of stars and the strength of Saturn. We believe
              in uplifting women by providing them with opportunities, resources, and a community
              that supports their growth and independence.
            </p>
            <ul className="list-disc list-inside space-y-2 text-lg">
              <li>🌟 Promoting education and skill development for women</li>
              <li>💪 Building confidence and leadership among girls</li>
              <li>🌍 Creating safe and inclusive communities</li>
              <li>🤝 Networking and mentorship opportunities</li>
              <li>✨ Celebrating achievements and sharing success stories</li>
            </ul>
          </section>

          <section className="bg-purple-700 bg-opacity-50 p-6 rounded-2xl shadow-lg mb-10">
            <h2 className="text-3xl font-semibold mb-4">Join the Movement</h2>
            <p className="text-lg mb-4">📌 <a href="https://docs.google.com/forms/d/e/1FAIpQLSfIm4Dv77dIi1n3odWoKRVUcfuCsOfFGxhoMtE8UrXU5upX5Q/viewform?usp=header" className="underline text-purple-200 hover:text-white" target="_blank" rel="noopener noreferrer">Click here</a> to become a part of Umeed Ki Kiran.</p>
          </section>
        </main>

        <footer className="text-center py-6 bg-black bg-opacity-70 mt-10">
          <p className="text-sm">© 2025 Umeed Ki Kiran NGO. All rights reserved.</p>
        </footer>
      </div>
    </div>
  );
}
